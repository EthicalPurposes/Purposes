# Auto-Hit-Method
  Basically, you upload the website and advertise it as free javascript link generator, while all logs are being sent to you and the users who use your site aka. dualhooking.


# How to use
  Read the txt file



# Disclaimer
## I, the creator, am in no way responsible for any actions that you may make using this software. You take full responsibility with any action taken using this software. Please take note that this application was designed for educational purposes and should never be used maliciously. By downloading the software or source to the software, you automatically accept this agreement.
